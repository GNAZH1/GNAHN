import os

class Config:
    API_ID = int(os.getenv("26957529", ))
    API_HASH = os.getenv("ffe7d862b0a31893682a62bbc0654ced", '')
    BOT_TOKEN = os.getenv("7490050559:AAFdSdgHNt6CFWrKnB106v3ly1_cpcav8ZM", '')
