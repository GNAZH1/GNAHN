#start, help $ other msgers..

class script(object):
  START_TXT = """
  𝙷𝚎𝚕𝚕𝚘 {}, 𝙸'𝚊𝚖 <a href='https://github.com/kalanakt/Pyrogram-Telegram-Bot-Template'>Pyrogram Bot</a>
  𝙰 𝚂𝚒𝚖𝚙𝚕𝚎 𝙱𝚘𝚝.  
  """
  
  HELP_TXT = """
  add help message for users
  """
  
  ABOUT_TXT = """
✯ 𝙼𝚢 𝙽𝚊𝚖𝚎 : <a href='https://github.com/kalanakt/Pyrogram-Telegram-Bot-Template'>Pyrogram Bot</a>
✯ 𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : <a href='https://docs.pyrogram.org/'>𝙿𝚢𝚛𝚘𝚐𝚛𝚊𝚖 v𝟷.𝟸.𝟸𝟶</a>
✯ 𝚂𝚎𝚛𝚟𝚎𝚛 : <a href='https://dashboard.heroku.com/'>𝙷𝚎𝚛𝚘𝚔𝚞</a>
✯ 𝙻𝚊𝚗𝚐𝚞𝚊𝚐𝚎 : <a href='https://docs.python.org/3/'>𝙿𝚢𝚝𝚑𝚘𝚗 𝟹.𝟿.𝟿</a>
✯ 𝙳𝚊𝚝𝚊𝙱𝚊𝚜𝚎 : <a href='https://mongodb.com/'>𝙼𝚘𝚗𝚐𝚘𝙳𝙱</a>
✯ 𝙱𝚊𝚜𝚎 𝚂𝚘𝚞𝚛𝚌𝚎 𝙲𝚘𝚍𝚎 : <a href='https://github.com/kalanakt/Pyrogram-Telegram-Bot-Template'>Pyrogram Telegram Bot Template</a>
✯ 𝚄𝚙𝚍𝚊𝚝𝚎 𝙲𝚑𝚊𝚗𝚗𝚎𝚕 : <a href='https://t.me/TMWAD'>𝙲𝚕𝚒𝚌𝚔 𝙷𝚎𝚛𝚎</a>
✯ 𝙼𝚊𝚒𝚗𝚝𝚎𝚗𝚊𝚗𝚌𝚎 : <a href='https://github.com/kalanakt'>𝙷𝚊𝚜𝚑𝙼𝚒𝚗𝚗𝚎𝚛</a>
"""
